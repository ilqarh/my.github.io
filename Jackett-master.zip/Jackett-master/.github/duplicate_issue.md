Duplicate of #{{ chosenIssue.number }}

Hi @{{ payload.sender.login }},

This issue looks similar to #{{ chosenIssue.number }}. 

To prevent issue tracker clutter, this issue will now be closed. If you feel this issue isn't a duplicate of #{{ chosenIssue.number }}, then feel free to post a comment on this issue stating why it's not a duplicate. Your comment will automatically re-open this issue.
